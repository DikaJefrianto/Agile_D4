<x-useravatar::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('useravatar.name') !!}</p>
</x-useravatar::layouts.master>

<?php

return [
    'name' => 'UserAvatar',
];

<?php

namespace Modules\UserAvatar\Services;

class SettingHooks
{
    public function register(): void
    {
        ld_add_filter('settings_general_tab_after_section_end', [$this, 'addNewSettingsSection'], 10, 1);
        ld_add_filter('settings_tabs', [$this, 'addAnotherSettingsTab'], 10, 1);
    }

    public function addNewSettingsSection($html = ''): string
    {
        return $html . view('useravatar::settings-another-section')->render();
    }

    public function addAnotherSettingsTab($tabs): array
    {

        return array_merge($tabs, [
            'another' => [
                'title' => __('Another Settings'),
                'view' => 'useravatar::settings-another-tab',
            ],
        ]);
    }
}

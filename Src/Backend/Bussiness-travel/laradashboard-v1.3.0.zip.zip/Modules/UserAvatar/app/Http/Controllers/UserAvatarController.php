<?php

namespace Modules\UserAvatar\Http\Controllers;

class UserAvatarController extends \App\Http\Controllers\Controller
{
}
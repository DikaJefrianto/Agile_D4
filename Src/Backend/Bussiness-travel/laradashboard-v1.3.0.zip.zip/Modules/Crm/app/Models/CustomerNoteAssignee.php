<?php

namespace Modules\Crm\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerNoteAssignee extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'customer_note_id',
        'user_id',
    ];

    public function note()
    {
        return $this->belongsTo(CustomerNote::class, 'customer_note_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}

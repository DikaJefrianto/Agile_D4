<?php

namespace Modules\Crm\Models;

use Illuminate\Database\Eloquent\Model;

class CustomerContactGroup extends Model
{
    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = ['customer_id', 'contact_group_id'];

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function contactGroup()
    {
        return $this->belongsTo(ContactGroup::class);
    }
}

<?php

namespace Modules\Crm\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Modules\Crm\Database\Factories\CustomerFactory;
use Modules\Crm\Enums\CustomerType;

class Customer extends Model
{
    use HasFactory;

    public static $factory = CustomerFactory::class;

    protected $fillable = [
        'uuid',
        'prefix',
        'first_name',
        'last_name',
        'full_name',
        'email',
        'phone',
        'dob',
        'company',
        'industry',
        'type',
        'status_id',
        'assigned_to',
        'converted_at',
        'website',
        'source',
        'summary',
        'custom_fields',
        'social_links',
        'is_active',
        'user_id',
    ];

    protected $casts = [
        'custom_fields' => 'array',
        'converted_at' => 'datetime',
        'is_active' => 'boolean',
        'type' => CustomerType::class,
    ];

    protected $attributes = [
        'type' => CustomerType::LEAD,
    ];

    public function status(): BelongsTo
    {
        return $this->belongsTo(LeadStatus::class, 'status_id');
    }

    public function assignedTo(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function deals(): HasMany
    {
        return $this->hasMany(Deal::class);
    }

    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    public function communications(): HasMany
    {
        return $this->hasMany(Communication::class);
    }

    public function notes(): HasMany
    {
        return $this->hasMany(CustomerNote::class);
    }

    public function contactTags()
    {
        return $this->belongsToMany(ContactTag::class, 'customer_tags')
            ->withPivot('created_at', 'updated_at');
    }

    public function contactGroups()
    {
        return $this->belongsToMany(ContactGroup::class, 'customer_contact_groups')
            ->withPivot('created_at', 'updated_at');
    }

    public function address()
    {
        return $this->hasMany(CustomerAddress::class);
    }

    public function primaryAddress()
    {
        return $this->hasOne(CustomerAddress::class)->where('is_primary', true);
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}

<?php

namespace Modules\Crm\Models;

use Illuminate\Database\Eloquent\Model;

class LeadStatus extends Model
{
    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'name',
        'color',
    ];

    public function customers()
    {
        return $this->hasMany(Customer::class, 'status_id');
    }
}

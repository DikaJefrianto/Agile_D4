<?php

namespace Modules\Crm\Models;

use App\Enums\NoteType;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class CustomerNote extends Model
{
    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'customer_id',
        'title',
        'note',
        'created_by',
        'updated_by',
        'attachments',
        'tags',
    ];

    protected $casts = [
        'attachments' => 'array',
        'tags' => 'array',
        'type' => NoteType::class,
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function assignees()
    {
        return $this->hasMany(CustomerNoteAssignee::class, 'customer_note_id');
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class, 'customer_id');
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function updater()
    {
        return $this->belongsTo(User::class, 'updated_by');
    }
}

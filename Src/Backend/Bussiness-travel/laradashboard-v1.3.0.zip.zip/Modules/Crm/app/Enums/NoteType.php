<?php

namespace Modules\Crm\Enums;

enum NoteType: string
{
    case NOTE = 'note';
    case EMAIL = 'email';
    case SMS = 'sms';
    case CALL = 'call';
    case MEETING = 'meeting';
    case TASK = 'task';
    case FOLLOW_UP = 'follow_up';
    case REMINDER = 'reminder';
    case SCHEDULE = 'schedule';
    case TRANSACTION = 'transaction';
    case FEEDBACK = 'feedback';

    // Social Share.
    case SOCIAL_SHARE_TWITTER = 'social_share_twitter';
    case SOCIAL_SHARE_FACEBOOK = 'social_share_facebook';
    case SOCIAL_SHARE_LINKEDIN = 'social_share_linkedin';
    case SOCIAL_SHARE_INSTAGRAM = 'social_share_instagram';

    // Quote.
    case QUOTE_SENT = 'quote_sent';
    case QUOTE_ACCEPTED = 'quote_accepted';
    case QUOTE_REJECTED = 'quote_rejected';

    // Invoice.
    case INVOICE_SENT = 'invoice_sent';
    case INVOICE_PAID = 'invoice_paid';
    case INVOICE_PARTIALLY_PAID = 'invoice_partially_paid';
    case INVOICE_REFUNDED = 'invoice_refunded';

    // Get all enum values as an array.
    public static function getValues(): array
    {
        return array_map(fn($enum) => $enum->value, self::cases());
    }

    // labels for the enums.
    public function label(): string
    {
        return match ($this) {
            self::NOTE => 'Note',
            self::EMAIL => 'Email',
            self::SMS => 'SMS',
            self::CALL => 'Call',
            self::MEETING => 'Meeting',
            self::TASK => 'Task',
            self::FOLLOW_UP => 'Follow Up',
            self::REMINDER => 'Reminder',
            self::SCHEDULE => 'Schedule',
            self::TRANSACTION => 'Transaction',
            self::FEEDBACK => 'Feedback',
            self::SOCIAL_SHARE_TWITTER => 'Twitter Share',
            self::SOCIAL_SHARE_FACEBOOK => 'Facebook Share',
            self::SOCIAL_SHARE_LINKEDIN => 'LinkedIn Share',
            self::SOCIAL_SHARE_INSTAGRAM => 'Instagram Share',
            self::QUOTE_SENT => 'Quote Sent',
            self::QUOTE_ACCEPTED => 'Quote Accepted',
            self::QUOTE_REJECTED => 'Quote Rejected',
            self::INVOICE_SENT => 'Invoice Sent',
            self::INVOICE_PAID => 'Invoice Paid',
            self::INVOICE_PARTIALLY_PAID => 'Invoice Partially Paid',
            self::INVOICE_REFUNDED => 'Invoice Refunded'
        };
    }

    public function icon(): string
    {
        return match ($this) {
            self::NOTE => 'bi bi-journal-text',
            self::EMAIL => 'bi bi-envelope',
            self::SMS => 'bi bi-chat-dots',
            self::CALL => 'bi bi-telephone',
            self::MEETING => 'bi bi-people',
            self::TASK => 'bi bi-check2-circle',
            self::FOLLOW_UP => 'bi bi-arrow-repeat',
            self::REMINDER => 'bi bi-bell',
            self::SCHEDULE => 'bi bi-calendar',
            self::TRANSACTION => 'bi bi-cash-stack',
            self::FEEDBACK => 'bi bi-chat-left-text',
            self::SOCIAL_SHARE_TWITTER => 'bi bi-twitter',
            self::SOCIAL_SHARE_FACEBOOK => 'bi bi-facebook',
            self::SOCIAL_SHARE_LINKEDIN => 'bi bi-linkedin',
            self::SOCIAL_SHARE_INSTAGRAM => 'bi bi-instagram',
            self::QUOTE_SENT => 'bi bi-send',
            self::QUOTE_ACCEPTED => 'bi bi-check-circle',
            self::QUOTE_REJECTED => 'bi bi-x-circle',
            self::INVOICE_SENT => 'bi bi-file-earmark-text',
            self::INVOICE_PAID => 'bi bi-currency-dollar',
            self::INVOICE_PARTIALLY_PAID => 'bi bi-currency-exchange',
            self::INVOICE_REFUNDED => 'bi bi-arrow-counterclockwise'
        };
    }
}

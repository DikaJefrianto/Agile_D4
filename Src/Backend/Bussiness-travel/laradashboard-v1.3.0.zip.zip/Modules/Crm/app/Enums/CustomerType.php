<?php

namespace Modules\Crm\Enums;

enum CustomerType: string
{
    case LEAD = 'lead';
    case CUSTOMER = 'customer';
    case OPPORTUNITY = 'opportunity';
    case SUBSCRIBER = 'subscriber';

    // Get all enum values as an array.
    public static function getValues(): array
    {
        return array_map(fn($enum) => $enum->value, self::cases());
    }

    // labels for the enums.
    public function label(): string
    {
        return match ($this) {
            self::LEAD => 'Lead',
            self::CUSTOMER => 'Customer',
            self::OPPORTUNITY => 'Opportunity',
            self::SUBSCRIBER => 'Subscriber',
        };
    }

    public function icon(): string
    {
        return match ($this) {
            self::LEAD => 'bi bi-person-bounding-box',
            self::CUSTOMER => 'bi bi-person-check',
            self::OPPORTUNITY => 'bi bi-person-plus',
            self::SUBSCRIBER => 'bi bi-person-lines-fill',
        };
    }

    public function color(): string
    {
        return match ($this) {
            self::LEAD => '#357cf4',
            self::CUSTOMER => '#28a745',
            self::OPPORTUNITY => '#ff9200',
            self::SUBSCRIBER => '#6c757d',
        };
    }
}
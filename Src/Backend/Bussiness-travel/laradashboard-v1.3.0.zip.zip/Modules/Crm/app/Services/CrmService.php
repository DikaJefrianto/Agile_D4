<?php

namespace Modules\Crm\Services;

class CrmService
{
    public function bootstrap()
    {
        ld_add_filter('sidebar_menu_after_users', [$this, 'addCrmMenu']);
    }

    public function addCrmMenu($html = '')
    {
        return $html . view('crm::partials.crm-menu')->render();
    }
}

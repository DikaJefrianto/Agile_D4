<?php

namespace Modules\Crm\Services;

use App\Services\UserService;
use Modules\Crm\Models\Customer;

class CustomerService
{
    public function __construct(private readonly UserService $userService)
    {
    }

    private function _buildCustomerQuery($filter = null)
    {
        if ($filter === null) {
            $filter = request()->all();
        }

        $query = Customer::query();

        $query->with(['status']);

        if (isset($filter['search'])) {
            $query->where(function ($q) use ($filter) {
                $q->where('name', 'LIKE', '%' . $filter['search'] . '%')
                    ->orWhere('email', 'LIKE', '%' . $filter['search'] . '%')
                    ->orWhere('phone', 'LIKE', '%' . $filter['search'] . '%');
            });
        }

        if (isset($filter['status'])) {
            $query->where('status', $filter['status']);
        }

        return $query;
    }

    public function getCustomers($perPage = 20, $filter = null)
    {
        $query = $this->_buildCustomerQuery($filter);

        return $query->paginate($perPage);
    }

    public function getCount($filter = null)
    {
        $query = $this->_buildCustomerQuery($filter);

        return $query->count();
    }

    public function createCustomer(array $data): ?Customer
    {
        $user = $this->userService->createUser(
            array_merge(
                $data,
                [
                    'name' => $data['first_name'] . ' ' . $data['last_name'],
                    'roles' => ['customer'],
                ]
            )
        );

        $data['user_id'] = $user->id;
        $data = $this->processCustomerFormData($data);

        return Customer::create($data);
    }

    public function processCustomerFormData(array $data)
    {
        $data['uuid'] = (string) \Illuminate\Support\Str::uuid();

        return $data;
    }

    public function getCustomerByUuid($uuid): ?Customer
    {
        return Customer::where('uuid', $uuid)
            ->with(['user'])
            ->firstOrFail();
    }
}

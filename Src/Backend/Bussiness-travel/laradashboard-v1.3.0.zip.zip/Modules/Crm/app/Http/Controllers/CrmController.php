<?php

namespace Modules\Crm\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Contracts\Support\Renderable;
use Modules\Crm\Services\CustomerService;

class CrmController extends Controller
{
    public function __construct(private readonly CustomerService $customerService)
    {
    }

    /**
     * CRM Dashboard
     */
    public function dashboard(): Renderable
    {
        return view('crm::pages.dashboard.index', [
            'total_active_customers' => $this->customerService->getCount(['is_active' => 1]),
        ]);
    }
}

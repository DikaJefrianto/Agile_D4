<?php

namespace Modules\Crm\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Modules\Crm\Models\Customer;
use Modules\Crm\Services\CustomerService;

class CustomersController extends Controller
{
    public function __construct(private readonly CustomerService $customerService)
    {
    }

    /**
     * Display a listing of the resource.
     */
    public function index(): Renderable
    {
        $this->checkAuthorization(auth()->user(), ['customer.view']);

        return view(
            'crm::pages.customers.index',
            [
                'customers' => $this->customerService->getCustomers(),
            ]
        );
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('crm::pages.customers.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        $this->checkAuthorization(auth()->user(), ['customer.create']);

        $customer = $this->customerService->createCustomer($request->all());

        if (!$customer) {
            return redirect()->back()->with('error', 'Customer creation failed.');
        }

        return redirect()->route('admin.crm.customers.index')->with('success', 'Customer created successfully.');
    }

    /**
     * Show the specified resource.
     */
    public function show(string $uuid)
    {
        return view('crm::pages.customers.show', [
            'customer' => $this->customerService->getCustomerByUuid($uuid),
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $customer = Customer::findOrFail($id);

        return view('crm::pages.customers.edit', compact('customer'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $customer = Customer::findOrFail($id);
        $customer->update($request->all());

        return redirect()->route('admin.crm.customers.index')->with('success', 'Customer updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $customer = Customer::findOrFail($id);
        $customer->delete();

        return redirect()->route('admin.crm.customers.index')->with('success', 'Customer deleted successfully.');
    }
}

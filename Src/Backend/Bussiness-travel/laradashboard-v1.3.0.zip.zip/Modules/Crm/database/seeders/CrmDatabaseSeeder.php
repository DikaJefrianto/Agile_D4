<?php

namespace Modules\Crm\Database\Seeders;

use Illuminate\Database\Seeder;

class CrmDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $this->call([
            CrmRolePermissionSeeder::class,
            CustomerSeeders::class,
        ]);
    }
}

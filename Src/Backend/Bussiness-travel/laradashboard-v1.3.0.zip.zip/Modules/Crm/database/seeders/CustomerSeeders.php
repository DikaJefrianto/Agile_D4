<?php

namespace Modules\Crm\Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\Crm\Models\Customer;
use Modules\Crm\Models\LeadStatus;

class CustomerSeeders extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // LeadStatuses entries.
        LeadStatus::insert([
            ['name' => 'New', 'color' => '#357cf4'],
            ['name' => 'In Progress', 'color' => '#6060fa'],
            ['name' => 'Closed', 'color' => '#ff9200'],
            ['name' => 'Lost', 'color' => '#FF0000'],
        ]);

        // Customer entries.
        Customer::factory(50)->create(); // Create 50 customers
    }
}

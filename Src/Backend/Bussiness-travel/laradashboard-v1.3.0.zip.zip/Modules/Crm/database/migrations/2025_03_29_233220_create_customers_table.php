<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Modules\Crm\Enums\CustomerType;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->id();
            $table->string('uuid')->unique();
            $table->enum('prefix', ['Mr.', 'Ms.', 'Mrs.'])->nullable();
            $table->string('first_name');
            $table->string('last_name')->nullable();
            $table->string('full_name')->virtualAs('CONCAT(prefix, " ", first_name, " ", last_name)')->nullable();
            $table->string('email')->unique()->nullable();
            $table->string('phone')->nullable();
            $table->string('dob')->nullable();
            $table->string('company')->nullable();
            $table->string('industry')->nullable(); // e.g., IT, Retail, Finance
            $table->enum('type', CustomerType::getValues())->default(CustomerType::LEAD);
            $table->unsignedBigInteger('status_id')->nullable(); // New, In Progress, Converted, Lost
            $table->unsignedBigInteger('assigned_to')->nullable(); // Sales rep
            $table->timestamp('converted_at')->nullable(); // When lead became a customer
            $table->string('website')->nullable(); // Company website.
            $table->string('source')->nullable(); // Referral, Website, Ad, etc.
            $table->text('summary')->nullable(); // Summary of the customer
            $table->json('custom_fields')->nullable(); // Dynamic data
            $table->json('social_links')->nullable(); // Social media links
            $table->boolean('is_active')->default(true); // Soft deactivation
            $table->unsignedBigInteger('user_id')->nullable(); // A user must be associated with a customer.

            $table->foreign('status_id')->references('id')->on('lead_statuses')->onDelete('set null');
            $table->foreign('assigned_to')->references('id')->on('users')->onDelete('set null');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('set null');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('customers');
    }
};

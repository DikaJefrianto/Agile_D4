<?php

declare(strict_types=1);

namespace Modules\Crm\Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Modules\Crm\Enums\CustomerType;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\Modules\Crm\Models\Customer>
 */
class CustomerFactory extends Factory
{
    protected $model = \Modules\Crm\Models\Customer::class;

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'prefix' => $this->faker->randomElement(['Mr.', 'Mrs.', 'Ms.']),
            'first_name' => $this->faker->firstName(),
            'last_name' => $this->faker->lastName(),
            'email' => $this->faker->unique()->safeEmail(),
            'phone' => $this->faker->phoneNumber(),
            'user_id' => User::factory()->create([
                'email' => $this->faker->unique()->safeEmail(),
                'password' => Hash::make('password'), // Default password
            ])->id,
            'uuid' => (string) \Illuminate\Support\Str::uuid(),
            'status_id' => $this->faker->randomElement([1, 2, 3, 4]), // Assuming these are valid status IDs
            'type' => $this->faker->randomElement(CustomerType::getValues()), // Randomly assign a customer type

            // Created at and updated_at would be random time between 1 year ago and now
            'created_at' => $this->faker->dateTimeBetween('-1 year', 'now'),
            'updated_at' => $this->faker->dateTimeBetween('-1 year', 'now'),
        ];
    }
}

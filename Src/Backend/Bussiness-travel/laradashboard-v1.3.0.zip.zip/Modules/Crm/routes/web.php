<?php

use Illuminate\Support\Facades\Route;
use Modules\Crm\Http\Controllers\CrmController;
use Modules\Crm\Http\Controllers\CustomersController;

Route::middleware(['auth', 'verified'])
    ->prefix('admin/crm')
    ->as('admin.crm.')
    ->group(function () {
        Route::get('dashboard', [CrmController::class, 'dashboard'])->name('dashboard');
        Route::resource('customers', CustomersController::class);
    });

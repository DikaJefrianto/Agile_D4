/**
 * External dependencies.
 */
import React from "react";
import { createRoot } from "react-dom/client";

/**
 * Internal dependencies.
 */

const CustomerDetail = ({ customer }) => {
  console.log("customer", customer);

  return (
    <div className="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
      <div x-data="{ pageName: 'Customers' }">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <h2
            className="text-xl font-semibold !text-gray-800 dark:!text-white/90"
            x-text="pageName"
          >
            Customers
          </h2>
          <nav>
            <ol className="flex items-center gap-1.5">
              <li>
                <a
                  className="inline-flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400"
                  href="/admin"
                >
                  Home
                  <i className="bi bi-chevron-right"></i>
                </a>
              </li>
              <li
                className="text-sm text-gray-800 dark:text-white/90"
                x-text="pageName"
              >
                Customers
              </li>
            </ol>
          </nav>
        </div>
      </div>

      <div className="space-y-6">
        {/* More details */}
        <div className="customer-info">
          <h3 className="text-lg font-semibold">{customer.full_name}</h3>
          <p>Name: {customer.full_name}</p>
          <p>Email: {customer.email}</p>
          <p>Phone: {customer.phone}</p>
        </div>
      </div>
    </div>
  );
};

export default CustomerDetail;

const page = document.getElementById("customer-detail-page");
if (page) {
  let customer = JSON.parse(page.dataset["customer"] || "{}");
  createRoot(page).render(<CustomerDetail customer={customer} />);
}

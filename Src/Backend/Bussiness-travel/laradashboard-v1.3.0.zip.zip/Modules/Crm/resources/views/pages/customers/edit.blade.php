@extends('crm::layouts.master')

@push('css')
@endpush

@section('title', 'Customer Details | CRM - ' . config('app.name'))

@section('content')
    <section class=" max-w-[1400px] md:mx-10 pt-11">
        Sample customer detail page.

        <div id="customer-detail-page" data-customer="{{ @json_encode($customer) }}"></div> <!-- Added customer detail page container -->
    </section>
@endsection

@push('js')
    @if (config('app.env') == 'production')
        @php
            $manifest = json_decode(file_get_contents(asset('build/manifest.json')), true);
        @endphp
        <script type="module" src="{{ asset("build/{$manifest['resources/js/customer.jsx']['file']}") }}"></script>
    @else
        @vitereactrefresh
        @vite('Modules/Crm/resources/assets/js/customer.js')
    @endif
@endpush

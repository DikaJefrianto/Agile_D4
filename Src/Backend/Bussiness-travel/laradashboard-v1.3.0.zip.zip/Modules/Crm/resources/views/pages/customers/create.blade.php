@extends('crm::layouts.master')

@section('title', 'New Customer - CRM | ' . config('app.name'))

@section('crm-admin-content')
<div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
    <div class="mb-6 flex flex-wrap items-center justify-between gap-3">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white/90">New Customer</h2>
        <nav>
            <ol class="flex items-center gap-1.5">
                <li>
                    <a class="inline-flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400" href="{{ route('admin.dashboard') }}">
                        Home
                        <i class="bi bi-chevron-right"></i>
                    </a>
                </li>
                <li class="text-sm text-gray-800 dark:text-white/90">New Customer</li>
            </ol>
        </nav>
    </div>
</div>
@endsection

@push('js')
    @if (config('app.env') == 'production')
        @php
            $manifest = json_decode(file_get_contents(asset('build/manifest.json')), true);
        @endphp
        <script type="module" src="{{ asset("build/{$manifest['resources/js/customer.jsx']['file']}") }}"></script>
    @else
        @vitereactrefresh
        @vite('Modules/Crm/resources/assets/js/customer.js')
    @endif
@endpush

<x-crm::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('crm.name') !!}</p>
</x-crm::layouts.master>

@extends('backend.layouts.app')

@section('title')
    @yield('crm-title', __('Customers | CRM - ' . config('app.name')))
@endsection

@push('styles')
    @vite(['Modules/Crm/Resources/assets/css/app.css'])
@endpush

@section('admin-content')
    <div class="crm-module">
        @yield('crm-admin-content')
    </div>
@endsection
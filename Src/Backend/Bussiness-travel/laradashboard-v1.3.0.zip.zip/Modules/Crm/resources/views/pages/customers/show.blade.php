@extends('crm::layouts.master')

@push('styles')
    @vitereactrefresh
    {{ module_vite('build-crm', 'resources/assets/css/customer.css') }}
    {{ module_vite('build-crm', 'resources/assets/js/customer.js') }}
@endpush

@section('title', $customer->full_name . ' - Details | CRM - ' . config('app.name'))

@section('crm-admin-content')
    <div id="customer-detail-page" data-customer="{{ @json_encode($customer) }}"></div>
@endsection

<?php

return [
    'name' => 'Crm',
];

import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const paths = [
    '/resources/assets/css/app.css',
    '/resources/assets/css/customer.css',

    '/resources/assets/js/app.js',
    '/resources/assets/js/customer.js',
];

export default defineConfig({
    build: {
        outDir: '../../public/build-crm',
        emptyOutDir: true,
    },
    paths,
    plugins: [
        laravel({
            publicDirectory: '../../public',
            buildDirectory: 'build-crm',
            input: [
                __dirname + '/resources/assets/css/app.css',
                __dirname + '/resources/assets/css/customer.css',

                __dirname + '/resources/assets/js/app.js',
                __dirname + '/resources/assets/js/customer.js',
            ],
            // input: paths,
            refresh: true,
        }),
        react(),
        tailwindcss({
            // You can add any module-specific Tailwind config here if needed
        }),
    ],
});
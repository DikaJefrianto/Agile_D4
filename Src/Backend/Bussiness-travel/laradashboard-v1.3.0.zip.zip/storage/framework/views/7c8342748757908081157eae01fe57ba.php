<table <?php echo e($attributes->merge(['class' => 'w-full'])); ?>>
    <?php echo e($slot); ?>

</table>
<?php /**PATH /Users/maniruzzamanakash/workspace/laravel-role/vendor/laravel/pulse/src/../resources/views/components/table.blade.php ENDPATH**/ ?>
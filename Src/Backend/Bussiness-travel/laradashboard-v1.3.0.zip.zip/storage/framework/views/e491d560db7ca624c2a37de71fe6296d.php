<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" fill="none" stroke-width="1.5" stroke="currentColor" <?php echo e($attributes); ?>>
    <path d="M2 15.6154H7.5L9.5 12L12 19L14.1094 15.6154H29.75" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
<?php /**PATH /Users/maniruzzamanakash/workspace/laravel-role/vendor/laravel/pulse/src/../resources/views/components/icons/no-pulse.blade.php ENDPATH**/ ?>